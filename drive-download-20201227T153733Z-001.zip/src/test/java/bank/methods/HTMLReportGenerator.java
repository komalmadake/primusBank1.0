package bank.methods;

public class HTMLReportGenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
