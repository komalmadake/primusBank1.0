package bank.UnitSteps;

public class TemptJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
