package bank.UnitSteps;

public interface Parameters
{

  String bname="chrome";
 String driverexepath= "E:\\PrimusBank\\src\\test\\resources\\DRIVERS\\chromedriver.exe";
 
		  
	
	
	
	
	
	
}
